// TODO 3: Import data students dari folder data/students.js
const students = require('../data/students');

// Membuat Class StudentController
class StudentController {
  index(req, res) {
    // TODO 4: Tampilkan data students
    res.status(200).json({
      message: "Menampilkan semua students",
      data: students,
    });
  }

  store(req, res) {
    // TODO 5: Tambahkan data students
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ message: "Name is required" });
    }
    students.push(name);
    res.status(201).json({
      message: `Menambahkan data student: ${name}`,
      data: students,
    });
  }

  update(req, res) {
    // TODO 6: Update data students
    const { id } = req.params;
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ message: "Name is required" });
    }

    const studentIndex = parseInt(id, 10) - 1; // Adjusting for array index
    if (studentIndex < 0 || studentIndex >= students.length) {
      return res.status(404).json({ message: "Student not found" });
    }

    students[studentIndex] = name;
    res.status(200).json({
      message: `Mengedit student id ${id}, nama ${name}`,
      data: students,
    });
  }

  destroy(req, res) {
    // TODO 7: Hapus data students
    const { id } = req.params;
    const studentIndex = parseInt(id, 10) - 1; // Adjusting for array index

    if (studentIndex < 0 || studentIndex >= students.length) {
      return res.status(404).json({ message: "Student not found" });
    }

    students.splice(studentIndex, 1);
    res.status(200).json({
      message: `Menghapus student id ${id}`,
      data: students,
    });
  }
}

// Membuat object StudentController
const object = new StudentController();

// Export object StudentController
module.exports = object;
