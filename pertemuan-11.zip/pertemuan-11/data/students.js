// TODO 1: Buat data students
const students = ["Adi Putra", "Siti Aminah", "Budi Santoso", "Rina Ayu", "Dewi Kartika"];

// TODO 2: export data students
module.exports = students;
